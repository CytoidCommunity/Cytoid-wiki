“PCtyx to Cytus II Chart Converter” by Lumixanth
Current version: 1.1


[About]
The converter converts a PCtyx chart file (.csv) to a Cytus II one, where the converted chart is aimed to be official-like. Source codes are written in Java.


[System Requirements]
- Supports Windows and macOS platforms.
- Must have at least Java 8 installed.


[Converter Features]
- Tons of debugs for input fields.
  This is not a significant feature but makes sure the converter doesn't breakdown caused by dummy inputs. It also reminds users what silly mistakes they make.
  
- Converts PCtyx charts with offsets smoothly while playing in Cytoid.
  While using non-Cytoid programs to demonstrate, make sure to check the value of music_offset parameter in converted charts then add the given value of silence in seconds to the beginning of the audio before previewing.
  
- Supports frozen scanlines by modifying PCtyx charts.
  By doing so, go to the last column in the targeted SECTION line. Change it to 2 for floor freeze or 3 for ceiling freeze.
  
- Makes adding approach rate (AR) for notes more easily.
  This can be done by modifying PCtyx charts as well. Go to the targeted note line and add an extra column at the end, then type the desired AR in it for the targeted note and the ones after it. If another AR is needed just do the same thing, the previous one will then replace to the new one. This makes inputting ARs for a huge amount of notes simpler.


[How to Use]
No matter which platform the system is, there should be one executable file and one JAR file. Click on the executable file to use the converter while making sure those two files are placed in the same directory.

But on macOS, the execute permission hasn't been given to it yet. Below are the steps of giving it the permission:
- Open Terminal and type “chmod +x ”.
- Then drag the .command file on Terminal to fill the path automatically, after that it should be like “chmod +x [file_path]” .
- Press Enter.
Now the executable file should work properly, just double-click it and let it open in Terminal.



[FAQ]
Q: Why the converter keeps crashing?
A: Check if you meet the requirements above, most people have this problem because they do not have Java installed in their system.

Q: How to input BPM constant field? Do I have to enter “N” if my chart has speed changes?
A: Remember the field asks for song BPM, not chart BPM. So if your target song has a constant bpm, just enter “Y”. In addition, you can skip all page size checks during converting progress if entering “Y”.

Q: Do I just literally input song BPM in song BPM field?
A: Yes, no doubts. By the way, what you input will be directly converted to the tempo parameter in converted charts. So make sure to enter it correctly.

Q: What in the world is speed rate? I also don't quite understand what beginning speed rate is. Can I just skip it for my lazy bones?
A: At first, why this field exists is because Cytus II format has a functionally same parameter. Its purpose is to note what the upcoming speed status is (faster, slower, or same as base speed), you'll have to enter at least one speed rate during converting progress. Shortly, you only do easy calculations by letting your desired base speed (in sec/page) divided by current speed (in sec/page). For example, if the former is 0.6 secs and the latter is 1.2 secs, simply do the division and you'll get 0.5. Just type the result in the field.
   Second, the word beginning stands for that of the chart, which means you'll only need to calculate speed rate of the first page. Rest of the steps are same as above.
   Lastly, it's still unclear that if the parameter has any effect on chart playthrough, but if you find it too perplexing just enter it 1.